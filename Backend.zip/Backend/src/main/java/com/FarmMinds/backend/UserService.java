package com.FarmMinds.backend;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    private BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public User registerUser(UserDTO userDTO) throws Exception {
        if (userRepository.findByEmail(userDTO.getEmail()) != null) {
            throw new Exception("User already exists with this email");
        }

        User user = new User();
        user.setName(userDTO.getName());
        user.setEmail(userDTO.getEmail());
        user.setPassword(passwordEncoder.encode(userDTO.getPassword()));
        user.setUserType(userDTO.getUserType());
        user.setGovtId(userDTO.getUserType().equals("farmer") ? userDTO.getGovtId() : null);
        user.setAddress(userDTO.getAddress());
        user.setPhoneNumber(userDTO.getUserType().equals("farmer") ? userDTO.getPhoneNumber() : null);

        return userRepository.save(user);
    }
 
 // Get all users
    public List<User> getAllUsers() {
        return userRepository.findAll(); // Fetch all users from the database
    }	

    public boolean loginUser(String email, String password) {
        User user = userRepository.findByEmail(email);
        return user != null && passwordEncoder.matches(password, user.getPassword());
    }

    public User addUser(User user) {
        return userRepository.save(user);
    }
}
