package com.FarmMinds.backend;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")  // Base URL for all endpoints
public class UserController {

    @Autowired
    private DAO dao;  // Assuming your DAO handles DB operations

    @Autowired
    private UserService userService;  // Assuming your service handles business logic

    // 1. Get all users - For your frontend to display user data
    @GetMapping("/users")
    public ResponseEntity<List<User>> getAllUsers() {
        List<User> users = dao.retrieveAll();  // Fetch all users from DB
        return new ResponseEntity<>(users, HttpStatus.OK);
    }

    // 2. Get a user by email - For your frontend to retrieve a specific user
    @GetMapping("/user")
    public ResponseEntity<User> getUserByEmail(@RequestParam("email") String email) {
        User user = dao.findUser(email);  // Retrieve user by email
        if (user != null) {
            return new ResponseEntity<>(user, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);  // If user not found
    }

    @DeleteMapping("/delete")
    public String fun5(@RequestParam("email") String email) {
        System.out.println("Attempting to delete user with email: " + email);
        return dao.deleteUser(email);
    }



    // 4. Update a user - For your frontend to update user information
    @PutMapping("/update")
    public ResponseEntity<String> updateUser(@RequestBody UserDTO userDTO) {
        try {
            User user = dao.findUser(userDTO.getEmail());
            if (user != null) {
                // Update the user details, password is optional
                if (userDTO.getPassword() != null) {
                    user.setPassword(userDTO.getPassword()); // Update password if provided
                }
                user.setName(userDTO.getName());
                user.setRole(userDTO.getUserType()); // Assuming 'role' maps to userType in the DTO
                user.setGovtId(userDTO.getGovtId());
                user.setAddress(userDTO.getAddress());
                user.setPhoneNumber(userDTO.getPhoneNumber());

                dao.updateUser(user);  // Update user in the database
                return new ResponseEntity<>("User updated successfully", HttpStatus.OK);
            }
            return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>("Error updating user", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    // 5. Sign-up endpoint (Already present in your code)
    @PostMapping("/signup")
    public ResponseEntity<String> signUpUser(@Validated @RequestBody UserDTO userDTO) {
        try {
            userService.registerUser(userDTO);
            return new ResponseEntity<>("Sign-up successful", HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    // 6. Sign-in endpoint (Already present in your code)
    @PostMapping("/signin")
    public ResponseEntity<String> signInUser(@RequestBody UserDTO userDTO) {
        if (userService.loginUser(userDTO.getEmail(), userDTO.getPassword())) {
            return new ResponseEntity<>("Login Successful", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Invalid credentials", HttpStatus.UNAUTHORIZED);
        }
    }
    @PostMapping("/add")
    public ResponseEntity<String> addUser(@Validated @RequestBody UserDTO userDTO) {
        try {
            User newUser = new User();
            newUser.setEmail(userDTO.getEmail());
            newUser.setName(userDTO.getName());
            newUser.setPassword(userDTO.getPassword());
            newUser.setUserType(userDTO.getUserType());
            newUser.setAddress(userDTO.getAddress());

            // If user is a Farmer, add additional fields
            if (userDTO.getUserType().equalsIgnoreCase("Farmer")) {
                newUser.setGovtId(userDTO.getGovtId());
                newUser.setPhoneNumber(userDTO.getPhoneNumber());
            }

            userService.registerUser(userDTO);
            return new ResponseEntity<>("User added successfully", HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>("Error adding user: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}