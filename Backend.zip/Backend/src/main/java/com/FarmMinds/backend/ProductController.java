package com.FarmMinds.backend;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@RestController
@RequestMapping("/api")  // Base URL for all endpoints
public class ProductController {

    @Autowired
    private ProductRepository productRepository;

    // Define the directory where you want to save the uploaded image
    private static final String UPLOAD_DIR = "C:\\Users\\DEEPAK NAYAK\\FarmMinds/";  // Update this path

    // Add a product (with image upload)
    @PostMapping("/products")
    public ResponseEntity<?> addProduct(@RequestParam("name") String name,
                                         @RequestParam("type") String type,
                                         @RequestParam("price") double price,
                                         @RequestParam("quantity") int quantity,
                                         @RequestParam("image") MultipartFile image) throws IOException {

        // Create a directory if it doesn't exist
        File directory = new File(UPLOAD_DIR);
        if (!directory.exists()) {
            directory.mkdirs();
        }

        // Get the original file name and create a path
        String imageName = image.getOriginalFilename();
        Path path = Paths.get(UPLOAD_DIR + imageName);

        // Save the image to the directory
        Files.write(path, image.getBytes());

        // Create Product object and set its fields
        Product product = new Product();
        product.setName(name);
        product.setType(type);
        product.setPrice(price);
        product.setQuantity(quantity);
        product.setImagePath(path.toString());  // Store the path of the saved image

        // Save the product in the database
        Product savedProduct = productRepository.save(product);

        // Return saved product in the response
        return new ResponseEntity<>(savedProduct, HttpStatus.CREATED);
    }

    // Get all products (for AdminDashboard)
    @GetMapping("/products")
    public ResponseEntity<List<Product>> getAllProducts() {
        List<Product> products = productRepository.findAll();
        return new ResponseEntity<>(products, HttpStatus.OK);
    }

    // Get a specific product by ID
    @GetMapping("/products/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable Long id) {
        return productRepository.findById(id)
                .map(product -> new ResponseEntity<>(product, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Delete a product by ID
    @DeleteMapping("/products/{id}")
    public ResponseEntity<String> deleteProduct(@PathVariable Long id) {
        if (productRepository.existsById(id)) {
            productRepository.deleteById(id);
            return new ResponseEntity<>("Product deleted successfully", HttpStatus.OK);
        }
        return new ResponseEntity<>("Product not found", HttpStatus.NOT_FOUND);
    }
}
