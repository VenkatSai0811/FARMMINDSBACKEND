package com.FarmMinds.backend;

import java.util.List;

public interface UserDAO {
    void insert(User user);
    List<User> retrieveAll();
    User findUser(String email);
    String deleteUser(String email);
    String updateUser(User user);
    List<User> page(int page, int limit);
}
